-- JOIN-запрос показывает оценки студентов вместе с группой,
-- предметом, преподавателем, типом оценки и весом типа оценки.

SELECT
    s.full_name AS 'Студент',
    g.group_name AS 'Группа',
    sub.subject_name AS 'Предмет',
    u.full_name AS 'Преподаватель',
    gt.type_name AS 'Тип оценки',
    gt.weight AS 'Вес',
    gr.grade_value AS 'Оценка',
    gr.grade_date AS 'Дата',
    gr.comment AS 'Комментарий'
FROM grades gr
JOIN students s ON s.student_id = gr.student_id
JOIN groups g ON g.group_id = s.group_id
JOIN teacher_assignments ta ON ta.assignment_id = gr.assignment_id
JOIN subjects sub ON sub.subject_id = ta.subject_id
JOIN users u ON u.user_id = ta.teacher_user_id
JOIN grade_types gt ON gt.grade_type_id = gr.grade_type_id
ORDER BY
    g.group_name,
    s.full_name,
    sub.subject_name,
    gr.grade_date;
