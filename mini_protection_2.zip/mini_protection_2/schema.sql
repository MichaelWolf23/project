PRAGMA foreign_keys = ON;

CREATE TABLE roles (
    role_id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_id INTEGER NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

CREATE TABLE groups (
    group_id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_name TEXT NOT NULL UNIQUE,
    course_number INTEGER CHECK (course_number IS NULL OR course_number BETWEEN 1 AND 6),
    description TEXT
);

CREATE TABLE students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    student_card_number TEXT UNIQUE,
    email TEXT,
    phone TEXT,
    status TEXT NOT NULL DEFAULT 'Обучается'
        CHECK (status IN ('Обучается', 'Отчислен', 'Академический отпуск', 'Переведен', 'Выпустился')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES groups(group_id)
);

CREATE TABLE group_curators (
    group_curator_id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    curator_user_id INTEGER NOT NULL,
    assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (group_id, curator_user_id),
    FOREIGN KEY (group_id) REFERENCES groups(group_id),
    FOREIGN KEY (curator_user_id) REFERENCES users(user_id)
);

CREATE TABLE subjects (
    subject_id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE academic_periods (
    period_id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_name TEXT NOT NULL UNIQUE,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    is_archived INTEGER NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
    CHECK (date(start_date) <= date(end_date))
);

CREATE TABLE teacher_assignments (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_user_id INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    period_id INTEGER NOT NULL,
    UNIQUE (teacher_user_id, group_id, subject_id, period_id),
    FOREIGN KEY (teacher_user_id) REFERENCES users(user_id),
    FOREIGN KEY (group_id) REFERENCES groups(group_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (period_id) REFERENCES academic_periods(period_id)
);

CREATE TABLE classrooms (
    classroom_id INTEGER PRIMARY KEY AUTOINCREMENT,
    classroom_name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE lesson_schedule (
    schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER NOT NULL,
    classroom_id INTEGER,
    day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    valid_from TEXT,
    valid_to TEXT,
    FOREIGN KEY (assignment_id) REFERENCES teacher_assignments(assignment_id),
    FOREIGN KEY (classroom_id) REFERENCES classrooms(classroom_id)
);

CREATE TABLE lessons (
    lesson_id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER NOT NULL,
    schedule_id INTEGER,
    lesson_date TEXT NOT NULL,
    topic TEXT NOT NULL,
    classroom_id INTEGER,
    note TEXT,
    FOREIGN KEY (assignment_id) REFERENCES teacher_assignments(assignment_id),
    FOREIGN KEY (schedule_id) REFERENCES lesson_schedule(schedule_id),
    FOREIGN KEY (classroom_id) REFERENCES classrooms(classroom_id)
);

CREATE TABLE attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Присутствовал', 'Отсутствовал', 'Опоздал', 'Уважительная причина')),
    comment TEXT,
    marked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (lesson_id, student_id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(lesson_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE grade_types (
    grade_type_id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_name TEXT NOT NULL UNIQUE,
    weight REAL NOT NULL DEFAULT 1.0 CHECK (weight > 0),
    description TEXT
);

CREATE TABLE grades (
    grade_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    assignment_id INTEGER NOT NULL,
    lesson_id INTEGER,
    grade_type_id INTEGER NOT NULL,
    grade_value REAL NOT NULL,
    grade_date TEXT NOT NULL DEFAULT CURRENT_DATE,
    comment TEXT,
    created_by_user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT,
    CHECK (grade_value >= 0),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (assignment_id) REFERENCES teacher_assignments(assignment_id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(lesson_id),
    FOREIGN KEY (grade_type_id) REFERENCES grade_types(grade_type_id),
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id)
);

CREATE TABLE grade_retakes (
    retake_id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_grade_id INTEGER NOT NULL,
    old_value REAL NOT NULL,
    new_value REAL NOT NULL,
    retake_date TEXT NOT NULL DEFAULT CURRENT_DATE,
    reason TEXT,
    changed_by_user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (original_grade_id) REFERENCES grades(grade_id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by_user_id) REFERENCES users(user_id)
);

CREATE TABLE final_grades (
    final_grade_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    assignment_id INTEGER NOT NULL,
    period_id INTEGER NOT NULL,
    final_value REAL NOT NULL,
    calculated_average REAL,
    comment TEXT,
    approved_by_user_id INTEGER,
    approved_at TEXT,
    UNIQUE (student_id, assignment_id, period_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (assignment_id) REFERENCES teacher_assignments(assignment_id),
    FOREIGN KEY (period_id) REFERENCES academic_periods(period_id),
    FOREIGN KEY (approved_by_user_id) REFERENCES users(user_id)
);

CREATE TABLE curator_notifications (
    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    curator_user_id INTEGER NOT NULL,
    student_id INTEGER,
    group_id INTEGER,
    assignment_id INTEGER,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Новое' CHECK (status IN ('Новое', 'Прочитано', 'Закрыто')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at TEXT,
    FOREIGN KEY (curator_user_id) REFERENCES users(user_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (group_id) REFERENCES groups(group_id),
    FOREIGN KEY (assignment_id) REFERENCES teacher_assignments(assignment_id)
);

CREATE TABLE system_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    description TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_students_group ON students(group_id);
CREATE INDEX idx_assignments_teacher ON teacher_assignments(teacher_user_id);
CREATE INDEX idx_assignments_group_subject ON teacher_assignments(group_id, subject_id);
CREATE INDEX idx_lessons_assignment_date ON lessons(assignment_id, lesson_date);
CREATE INDEX idx_attendance_student ON attendance(student_id);
CREATE INDEX idx_grades_student_assignment ON grades(student_id, assignment_id);
CREATE INDEX idx_grades_type ON grades(grade_type_id);
CREATE INDEX idx_notifications_curator_status ON curator_notifications(curator_user_id, status);

INSERT INTO roles (role_name, description) VALUES
    ('Преподаватель', 'Ведет занятия, выставляет оценки и формирует отчеты'),
    ('Куратор группы', 'Следит за успеваемостью группы и получает уведомления'),
    ('Администратор', 'Управляет пользователями, правами доступа и настройками системы');

INSERT INTO grade_types (type_name, weight, description) VALUES
    ('Практическая работа', 1.0, 'Оценка за практическую работу'),
    ('Лабораторная работа', 1.2, 'Оценка за лабораторную работу'),
    ('Домашнее задание', 1.0, 'Оценка за домашнее задание'),
    ('Контрольная работа', 1.5, 'Оценка за контрольную работу'),
    ('Экзамен', 2.0, 'Оценка за экзамен или итоговую работу');

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
    ('Минимальная положительная оценка', '3', 'Минимальная оценка, при которой результат считается положительным'),
    ('Минимальная оценка шкалы', '2', 'Минимальное значение в шкале оценивания'),
    ('Максимальная оценка шкалы', '5', 'Максимальное значение в шкале оценивания');
